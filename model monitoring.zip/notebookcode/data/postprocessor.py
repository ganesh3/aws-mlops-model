def postprocess_handler():
    print("Hello from post-proc script!")